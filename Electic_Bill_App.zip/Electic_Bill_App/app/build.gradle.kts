plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.electric_bill_app"
    compileSdk = 35  // Use the latest available version

    defaultConfig {
        applicationId = "com.example.electric_bill_app"
        minSdk = 21
        //noinspection EditedTargetSdkVersion
        //noinspection OldTargetApi
        targetSdk = 35  // Match compileSdk for better compatibility
        versionCode = 1
        versionName = "1.0"

        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64") // Ensure support for required architectures
        }

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    // Enable CMake for native code
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1" // Specify a stable CMake version
        }
    }

    sourceSets {
        named("main") {
            jniLibs.srcDirs("src/main/jniLibs") // Ensure JNI libraries are included
        }
    }
}

dependencies {
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.constraintlayout)

    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}
