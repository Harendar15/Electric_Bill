package com.example.electric_bill_app;
//import com.example.electric_bill_app.R;




import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    static {
        System.loadLibrary("electricbill"); // Load the native library
    }

    private EditText unitsInput;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        unitsInput = findViewById(R.id.unitsInput);
        Button calculateButton = findViewById(R.id.calculateButton);
        resultText = findViewById(R.id.resultText);

        // Using Lambda instead of Anonymous Class
        calculateButton.setOnClickListener(v -> {
            String input = unitsInput.getText().toString();
                    if (!input.isEmpty()) {

                int units = Integer.parseInt(input);
                double billAmount = calculateBill(units);
                resultText.setText(getString(R.string.total_bill, billAmount));
            } else {
                resultText.setText(R.string.error_empty_input);
            }
        });
    }

    // Native method
    public native double calculateBill(int units);
}
