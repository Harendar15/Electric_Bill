#include <jni.h>

extern "C" JNIEXPORT jdouble JNICALL
Java_com_example_electric_1bill_1app_MainActivity_calculateBill(JNIEnv* env, jobject obj, jint units) {
    (void)env; // Prevent unused parameter warning
    (void)obj;

    double billAmount = 0.0; // Declare and initialize billAmount

    if (units <= 100) {
        billAmount = units * 5.0;
    } else if (units <= 200) {
        billAmount = (100 * 5.0) + ((units - 100) * 7.0);
    } else {
        billAmount = (100 * 5.0) + (100 * 7.0) + ((units - 200) * 10.0);
    }

    return billAmount;
}
